export const GLOBALTYPES = {
    AUTH: "AUTH"
}