// data/templates.js
export const templates = [
    {
      id: 1,
      name: 'Template 1',
      image: '/images/1131w-xkDELtpQH94.jpg',
      component: 'Template1',
    },
    {
      id: 2,
      name: 'Template 2',
      image: '/images/single_column_resume_template_2_120817dd43.png',
      component: 'Template2',
    },
  ];
  