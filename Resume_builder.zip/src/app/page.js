'use client';
import React from 'react';
import WebsiteFeatures from '@/components/Home/WebsiteFeatures';



const Home = () => {
  return (
    <>
      <WebsiteFeatures />
    </>
  );
};

export default Home;
